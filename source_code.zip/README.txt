------安装方式------

---Windows---

--需要准备的东西--

1.Nginx+PHP环境
2.手与眼睛
3.一个浏览器
4.网络支持
5.一个解压工具

--安装步骤--

1.下载wusheng233-blog-system
2.解压wusheng233-blog-system到Nginx的安装文件夹的html中
3.访问你的内网及端口进行安装

---Android---

--需要准备的东西--

1.KSWEB(Nginx+PHP环境)
2.手与眼睛
3.一个浏览器
4.网络支持
5.一个解压工具

--安装步骤--

1.下载wusheng233-blog-system
2.解压wusheng233-blog-system到/storage/emulated/0/htdocs/中
3.访问你的内网及端口进行安装

------开发帮助------

---目录结构---

-blogs(存放文章)
-config(配置文件存放处)
-css(mdui)
-fonts(mdui)
-icons(mdui)
-js(mdui)
-templates(模版存放处)

------⚠警告⚠------
Linux未经过测试，请注意稳定性
请使用PHP7.2，否则将出错