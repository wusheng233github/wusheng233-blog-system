<?php
mkdir("./blogs/" . $_POST['title']);
$create_file = fopen("./blogs/" . $_POST['title'] . "/index.php", "w");
$content = str_replace('未知作者',$_POST["name"],'<html>
<head>
<title>
<?php
$title = fopen("../../config/title.txt", "r") or die("wusheng233-blog-system---title-missing!");
echo fread($title,filesize("../../config/title.txt"));
fclose($title);
?>
</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=5.0">
<link rel="stylesheet" href="../../css/mdui.css"></link>
<script src="../../js/mdui.js"></script>
</head>
<body class="mdui-drawer-body-left">
<?php
include "../header.php";
include "../drawer.html";
?>
<div class="mdui-chip">
<span class="mdui-chip-icon"><i class="mdui-icon material-icons">&#xe7fc;</i></span>
<span class="mdui-chip-title">未知作者(未知邮箱)</span>
</div>
</body>
</html>');
$content2 = $content = str_replace('未知邮箱',$_POST["email"],$content);
$write_text = fopen("./blogs/" . $_POST['title'] . "/index.php", "w");
fwrite($write_text, $content);
header("location:./blogs/" . $_POST['title'] . "/index.php");
fclose($create_file);
fclose($write_text);