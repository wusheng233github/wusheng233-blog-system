------installation method------

---Windows---

---Things to prepare---

1. Nginx+PHP environment
2. Hands and eyes
3. A browser
4. Network support
5. A decompression tool

--Installation steps--

1. Download wusheng233-blog-system
2. Unzip wusheng233-blog-system into the html of the Nginx installation folder
3. Access your intranet and port to install

---Android--

---Things to prepare--

1.KSWEB(Nginx+PHP environment)
2. Hands and eyes
3. A browser
4.Network support
5. A decompression tool

--Installation steps--

1. Download wusheng233-blog-system
2. Unzip wusheng233-blog-system to /storage/emulated/0/htdocs/
3.Access your intranet and port to install

------development help------

---Directory structure---

---blogs(where articles are stored)
---config(where configuration files are stored)
---css(mdui)
---fonts(mdui)
-icons(mdui)
-js(mdui)
-templates(Template repository)

------ ⚠Warning⚠------
Linux is not tested, please pay attention to stability
Please use PHP 7.2, otherwise you will get an error